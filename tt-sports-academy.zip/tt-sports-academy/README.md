# T&T Sports Academy — Team Website

Static website for T&T Sports Academy, a football academy in Nigeria.

## Files
- `index.html` — the whole site (styles and scripts are inside it)
- `img/` — photos used on the page
- `vercel.json` — settings for Vercel hosting

## Edit players, staff, tournaments and fixtures
Open `index.html` and search for `const CLUB = {`.
Each player and staff member is one entry in that list. Players and staff marked
`sample: true` are placeholders: replace them with real people, or delete the line.
To add a real photo, put it in `img/` and set `photo: "img/your-photo.jpg"`.

## Push to GitHub
1. Create an empty repository on GitHub.
2. Upload everything in this folder (Add file → Upload files), or use:
   ```
   git init
   git add .
   git commit -m "T&T Sports Academy website"
   git branch -M main
   git remote add origin https://github.com/YOUR-USERNAME/YOUR-REPO.git
   git push -u origin main
   ```

## Publish on Vercel
vercel.com → Add New → Project → import the repo → Framework Preset: Other → Deploy.
Every push to `main` updates the live site.

## Contact
+234 816 618 6275 · tandtsportacademy@gmail.com
